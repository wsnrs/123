<?php

$wyc_api = 'http://www.aifamao.com/api/api.php?json=0&v=1&key=liaotianapi';

?>