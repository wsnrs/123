$('#hits').html('30');
